# TRX-VRC_Menu_Icons
These icons I've created myself and are allowing others to use completely for free. I only ask that you credit me when using them for commercial products.
